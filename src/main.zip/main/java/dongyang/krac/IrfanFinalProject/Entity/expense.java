package dongyang.krac.IrfanFinalProject.Entity;


import jakarta.persistence.*;
import lombok.*;

import java.time.LocalDate;

@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
@ToString
@Entity
public class expense {
    @Id
    @GeneratedValue
    private Long id;
    @Column
    private String description;
    @Column
    private LocalDate date;
    @ManyToOne
    @JoinColumn(name = "category_id")
    private category category;
    @Column
    private double amount;

    @ManyToOne
    @JoinColumn(name = "accounts_id")
    private account accounts;


}
